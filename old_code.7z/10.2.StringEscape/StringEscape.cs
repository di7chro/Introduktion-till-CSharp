﻿using System;

class StringEscape {
	public static void Main() {
		string s1 = "This is a normal piece of text";
		Console.WriteLine(s1);

		string s2 = "Double quotes (\") is important, and backslash (\\) too.";
		Console.WriteLine(s2);

		string s3 = "This long text probably \nneeds two line of space";
		Console.WriteLine(s3);

		string s4 = "Anna\t1\tAolgifhjgklfdu";
		string s5 = "Bertil\t2\tBT";
		string s6 = "Catrin\t3\tCAA";
		string s7 = "David\t4\tTEH";

		Console.WriteLine(s4);
		Console.WriteLine(s5);
		Console.WriteLine(s6);
		Console.WriteLine(s7);
	}
}
