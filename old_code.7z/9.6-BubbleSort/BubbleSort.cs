﻿using System;

class BubbleSort {
	const int SIZE = 10, MIN = 0, MAX = 100;

	public static void Main() {
		Random rand = new Random();
		short[] myArray = new short[SIZE];

		// Fylla arrayen med slumptal
		for (int i = 0; i < SIZE; i++) {
			myArray[i] = (short)rand.Next(MIN, MAX);
		}

		Console.WriteLine("Arrayen fore sortering:");
		for (int i = 0; i < SIZE; i++) {
			Console.WriteLine("myArray[{0}] : {1}", i, myArray[i]);
		}
		myBubbleSort(myArray);

		Console.WriteLine("Arrayen efter sortering:");
		for (int i = 0; i < SIZE; i++) {
			Console.WriteLine("myArray[{0}] : {1}", i, myArray[i]);
		}
	}

	static void myBubbleSort(short[] arr) {
		short temp = 0;

		for (int walker = 0; walker < arr.Length; walker++) {
			for (int sorter = 0; sorter < arr.Length - 1; sorter++) {
				if (arr[sorter] > arr[sorter + 1]) {
					temp = arr[sorter + 1];
					arr[sorter + 1] = arr[sorter];
					arr[sorter] = temp;
				}
			}
		}
	}
}
