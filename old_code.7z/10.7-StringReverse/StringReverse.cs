﻿using System;

class StringReverse {
	public static void Main() {
		string s = "Norrsken";

		string reversed, sorted;

		reversed = StupidReverse(s);
		Console.WriteLine("StupidReverse: " + reversed);

		reversed = GoodReverse(s);
		Console.WriteLine("GoodReverse: " + reversed);

		sorted = SortArray(s);
		Console.WriteLine("SortArray: " + sorted);
	}

	static string StupidReverse(string text) {
		char[] cArray = text.ToCharArray();
		string reverse = String.Empty;

		for (int i = cArray.Length - 1; i >= 0; i--) {
			reverse += cArray[i];
		}
		return reverse;
	}

	static string GoodReverse(string text) {
		char[] cArray = text.ToCharArray();
		Array.Reverse(cArray);
		return new string(cArray);
	}

	static string SortArray(string text) {
		char[] cArray = text.ToCharArray();
		Array.Sort(cArray);
		return new string(cArray);
	}

}
