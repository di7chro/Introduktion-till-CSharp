﻿using System;

class IndexOf {
	public static void Main() {
		string s1 = "Denna text kan vi halla pa att leka med en stund.";

		Console.WriteLine(s1.IndexOf("te"));
		Console.WriteLine(s1.IndexOf("tesdgfghgfd"));
		Console.WriteLine(s1.IndexOf("ed"));
		Console.WriteLine(s1.IndexOf("."));
		Console.WriteLine(s1.IndexOf("k"));
		Console.WriteLine(s1.IndexOf("k", 12));
		Console.WriteLine(s1.IndexOf("k", 34));
	}
}
