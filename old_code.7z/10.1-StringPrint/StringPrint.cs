﻿using System;

class StringPrint {
	public static void Main() {
		string messages = "This is just a test string";

		Console.WriteLine("MSG: {0}", messages);

		Console.WriteLine("message.Length = {0}", messages.Length);

		for (int i = 0; i < messages.Length; i++) {
			Console.WriteLine("messages[{0}] = {1}", i, messages[i]);
		}
	}
}
