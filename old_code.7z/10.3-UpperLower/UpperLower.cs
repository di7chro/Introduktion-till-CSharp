﻿using System;

class UpperLower {
	public static void Main() {
		string s1 = "    This Is jUsT a noRMal STRing    ";

		Console.WriteLine(s1.ToUpper());
		Console.WriteLine(s1.ToLower());
		Console.WriteLine(s1.TrimEnd());

		Console.WriteLine(s1.TrimStart());
		Console.WriteLine(s1.Trim());

	}
}
