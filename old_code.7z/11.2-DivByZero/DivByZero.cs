﻿using System;

class DivByZero {
	public static void Main() {
		float t = 5, n = 0, svar = 0;

		try {
			if (n == 0)
				throw new DivideByZeroException();
			svar = t / n;
			Console.WriteLine("Svar: {0}/{1} = {2}", t, n, svar);
		}
		catch (DivideByZeroException ex) {
			Console.WriteLine("Du kan inte dela med 0. Missade du det i 1:an?");
			Console.WriteLine(ex);
		}
		finally {
			Console.WriteLine("Finally kors alltid.");
		}
	}
}
