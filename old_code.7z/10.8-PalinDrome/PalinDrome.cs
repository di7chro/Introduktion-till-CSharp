﻿using System;

class PalinDrome {
	public static void Main() {
		string test = "Sallad i Dallas";

		test = test.ToLower();

		Console.WriteLine(isPalinDrome(test));
	}

	static bool isPalinDrome(string input) {
		int length = input.Length;

		// Jämför första mot sista tecknet
		for (int i = 0; i < length; i++) {
			if (input[i] != input[length - i - 1])
				return false;
		}
		return true;
	}
}
