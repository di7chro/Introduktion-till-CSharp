﻿using System;
using System.IO;

class ReadFile {
	public static void Main() {
		StreamReader reader = new StreamReader("../../exempel.txt");
		int lineNumber = 0;
		string line;

		// Läser in alla rader i textfilen
		do {
			line = reader.ReadLine();
			lineNumber++;
			Console.WriteLine("Line:{0}: {1}", lineNumber, line);
		} while(line != null);

		// Stäng filen när du är klar
		reader.Close();
	}
}
