﻿using System;

class Exceptions {
	const int SIZE = 10;

	public static void Main() {
		int[] arr = new int[SIZE];

		for (int i = 0; i < SIZE; i++) {
			arr[i] = i * 2;
		}

		try {
			for (int i = 0; i < 45; i++) {
				Console.WriteLine("arr[{0}] = {1}", i, arr[i]);
			}
		}
		catch (IndexOutOfRangeException iob) {
			Console.WriteLine("Du kan bara loopa innanfor arrayen (saklart)");
			Console.WriteLine(iob);
		}
		catch (Exception ex) {
			Console.WriteLine("Det bidde ett fel");
			Console.WriteLine(ex);
		}
	}
}
